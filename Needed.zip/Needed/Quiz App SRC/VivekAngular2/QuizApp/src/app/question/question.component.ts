import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {
  questionList : any;
  constructor() { 
    this.questionList = [
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     },
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     },
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     },
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     }
  ]}

  ngOnInit() {
  }

}
