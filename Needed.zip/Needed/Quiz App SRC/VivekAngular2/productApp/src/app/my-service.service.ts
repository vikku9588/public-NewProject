import { Injectable } from '@angular/core';
import {HttpModule, Http, Response} from '@angular/http'
import { Observable } from 'rxjs/Observable';

@Injectable()
export class MyService {

  value:string; 
  
  loading : boolean;
  constructor(private http: Http) {
  }

  getvalue(): Observable<Response> {
     return this.http.request('//jsonplaceholder.typicode.com/posts/1');
}
}
