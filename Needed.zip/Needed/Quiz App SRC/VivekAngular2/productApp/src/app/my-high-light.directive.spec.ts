import { MyHighLightDirective } from './my-high-light.directive';

describe('MyHighLightDirective', () => {
  it('should create an instance', () => {
    const directive = new MyHighLightDirective();
    expect(directive).toBeTruthy();
  });
});
