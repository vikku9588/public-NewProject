import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductRowComponent } from './product-row/product-row.component';
import { ProductImageComponent } from './product-image/product-image.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { ProductDepartmentComponent } from './product-department/product-department.component';
import { StudentComponent } from './student/student.component';
import { MyHighLightDirective } from './my-high-light.directive';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { MyService } from './my-service.service';
 
@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ProductRowComponent,
    ProductImageComponent,
    ProductDisplayComponent,
    ProductDepartmentComponent,
    StudentComponent,
    MyHighLightDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule
  ],
  providers: [ MyService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
