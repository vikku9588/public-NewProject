import { Component, OnInit, Input } from '@angular/core';
import {Article} from './article.model';

@Component({
  selector: 'app-article',
  host: { class: 'row'},
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {
  @Input() article: Article; 
  
  voteUp():boolean{
    this.article.votesup();
    return false;
  }

  voteDown():boolean{
    this.article.votesdown();
    return false;
  }

  ngOnInit() {
  }

}
