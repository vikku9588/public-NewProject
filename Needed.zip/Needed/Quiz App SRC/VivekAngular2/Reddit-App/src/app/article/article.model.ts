export class Article{
votes: number;
title: string;
link: string;

constructor( title: string,link: string, votes?:number){
    this.votes=votes || 0;
    this.title=title;
    this.link=link;
}

votesup():void{
    this.votes+=1;
}

votesdown():void{
    this.votes-=1;
}

}