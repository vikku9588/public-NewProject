import { Component, OnInit, Input, Output, EventEmitter,ViewContainerRef } from '@angular/core';
import { Question } from '../question/question.model';
import { Modal } from 'angular2-modal/plugins/bootstrap';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Overlay } from 'angular2-modal';


@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

 @Input() curIndx : number;
 @Input() qL : any ;
 @Input() temp : Question;
 ansList : Question[];
 len :number ;
 @Output()  queEmit : EventEmitter<any>;
 @Output() indxEmit : EventEmitter<any>;

 qD : Question ;

  constructor(overlay: Overlay,public modal : Modal,vcRef: ViewContainerRef,) {
    this.queEmit = new EventEmitter();
    this.indxEmit = new EventEmitter();
    overlay.defaultViewContainer = vcRef;
    this.ansList = new Array<Question>();
     
   }

  ngOnInit() {
  }

nextQ() : void{
  this.len = this.qL.length;
  console.log("CurrINDX  : " + this.curIndx + " LEN : " + this.len );

  //create submitted ans array
  this.ansList.push(this.temp);
  
  if(this.curIndx < this.qL.length - 1){
    this.curIndx =this.curIndx + 1;
    //console.log("Selected Value  : " );
    console.log("Curent Indx : " + this.curIndx);
  
    this.qD = this.qL[this.curIndx];
   
    this.queEmit.emit(this.qD);
    this.indxEmit.emit(this.curIndx);
  }else{
    this.modal.alert().title("Question Completed")
  }
}

prevQ() : void{

if(this.curIndx != 0){
  this.curIndx =this.curIndx - 1;
  console.log("Curent Indx : " + this.curIndx);
   this.qD = this.qL[this.curIndx];
   this.len = this.qL.length;
   this.queEmit.emit(this.qD);
   this.indxEmit.emit(this.curIndx);
}
}
submitAll() : void {
  this.nextQ();
  if(this.ansList[0] != null &&
    this.ansList[1] != null &&
    this.ansList[2] != null &&
    this.ansList[3] != null){
  
console.log("Submit ");
  this.modal.alert()
        .size('lg')
        .showClose(true)
        .title('Result of The Quiz')
        .body(`
             Question : ` +  this.ansList[0].question + ` <br>   Your Answer : ` + this.ansList[0].selectedAns  + ` <br>   Correct Answer : ` + this.qL[0].answer + `<br>`+
           `<br>Question : `+ this.ansList[1].question + ` <br>  Your Answer : ` + this.ansList[1].selectedAns  + ` <br>   Correct Answer : ` + this.qL[1].answer + `<br>`+
           `<br>Question : `+ this.ansList[2].question + ` <br>  Your Answer : ` + this.ansList[2].selectedAns  + ` <br>   Correct Answer : ` + this.qL[2].answer + `<br>`+
           `<br>Question : `+this.ansList[3].question + ` <br>   Your Answer : ` + this.ansList[3].selectedAns  + ` <br>   Correct Answer : ` + this.qL[3].answer 
            )
        .open().then();
  }
  console.log("Submit "+ this.ansList.length);

}

}
