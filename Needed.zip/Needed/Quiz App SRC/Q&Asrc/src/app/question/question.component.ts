import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Http, HttpModule, Response } from '@angular/http';
import { Question } from './question.model';

@Component({
  selector: 'app-question',
  //template : '<router-outlet></router-outlet>',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})

export class QuestionComponent implements OnInit {

  qList : Question[] ;
  indx : number ;
  boolVar : boolean = false;
  cnt :number ;
  constructor(private http : Http, private  questionData : Question ) {  
    this.startQuiz();
    this.indx =0;
  }

  ngOnInit() {
  }

  startQuiz(): void {
    
    this.http.request('./assets/questions.json').subscribe((res: Response) => {
        this.qList = res.json();
        this.cnt = this.qList.length ;
        this.questionData = this.qList[this.indx];
      });
  }

  showEmit(emitQD : Question) {  
    this.questionData = emitQD;
    console.log("qqqqqqqqqqqqqq " + emitQD);
 }

 showIndxEmit(i : number) {  
    this.indx = i;
     console.log( "Emittt :"+ i);
 }
}