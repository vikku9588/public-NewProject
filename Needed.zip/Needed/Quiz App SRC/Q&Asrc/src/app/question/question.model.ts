
export class Question{
    question :  string;
    Answer :  string;
    options : string[];
    selectedAns : string ;
    
    constructor (){

    }
}