import { Directive, ElementRef, HostListener,Input } from '@angular/core';

@Directive({
  selector: '[appMyHighLight]'
})
export class MyHighLightDirective { 
  
  @HostListener('mouseleave') onMouseLeave(){
    this.highlight('Yellow')
  }
  @HostListener('mouseenter') onMouseEnter(){
    this.highlight(null);
  }
  constructor(private el : ElementRef) {     
  }
  private highlight(color : string){
    this.el.nativeElement.style.backgroundColor = color;
  }
}
