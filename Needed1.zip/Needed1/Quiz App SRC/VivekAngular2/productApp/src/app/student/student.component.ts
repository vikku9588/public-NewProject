import { Component, OnInit } from '@angular/core';
import {  FormBuilder, FormGroup } from '@angular/forms'


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  marks : number[] = [55,80,60,45,90];
  totalNumber : number = 300;
  grade : string = 'B';
  myForm: FormGroup;

  constructor(fb: FormBuilder) {
    this.myForm = fb.group({
      'Name': ['ABC123'],
      'Pass' : ['Vivek']
    });
  }
   onSubmit(value: string): void {
    console.log('you submitted value:', value);
  }
  ngOnInit() {
  }

}
