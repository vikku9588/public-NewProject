import { Component } from '@angular/core';
import { Product } from './product-list/product.model';
import { Observable } from 'rxjs/Rx';
import { MyService } from './my-service.service';
import { Response} from '@angular/http'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  products: Product[];
  data: Object;

constructor(private myservice : MyService) {
    this.products = [
      new Product(
        'MYSHOES',
        'Black Running Shoes',
        '/resources/images/products/black-shoes.jpg',
        ['Men', 'Shoes', 'Running Shoes'],
        109.99),
      new Product(
        'NEATOJACKET',
        'Blue Jacket',
        '/resources/images/products/blue-jacket.jpg',
        ['Women', 'Apparel', 'Jackets & Vests'],
        238.99),
      new Product(
        'NICEHAT',
        'A Nice Black Hat',
        '/resources/images/products/black-hat.jpg',
        ['Men', 'Accessories', 'Hats'],
        29.99)
      ];
     var observable = Observable.interval(1000).take(5)
            .map(i => {console.log("i-=>"+i);return i*2});
            observable.subscribe(value => console.log("observer 1 received " + value));
    observable.subscribe(value => console.log("observer 2 received " + value));             

  }
  makeRequest() : void {
    this.myservice.getvalue().subscribe((res : Response) => {
        this.data = res.json();
        console.log("Service Response : " + this.data);
    });
  }
  ngOnInit(){
    this.makeRequest();
  }

  productWasSelected(product: Product): void {
    console.log('Product clicked: ', product);
  }
}
