import { Injectable } from '@angular/core';

@Injectable()
export class MyServiceService {
  questionList : any;
  constructor() { 
    this.questionList = [
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     },
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     },
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     },
     {
      "qDesc": "Which is a reserved word in the Java programming language",
      "qMark": 1,
      "qCorrect": "4",
      "qOption": ["Default handler","finally","throw handler","Java run time system"]
     }
  ]}
  
}

