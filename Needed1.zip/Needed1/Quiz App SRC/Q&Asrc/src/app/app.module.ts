import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { QuestionComponent } from './question/question.component';
import {Routes,RouterModule} from '@angular/router';
import { NavigationComponent } from './navigation/navigation.component';
import { Question } from './question/question.model';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
import { ModalModule } from 'angular2-modal';
import { Modal } from 'angular2-modal/plugins/bootstrap';
import { MainComponentComponent } from './main-component/main-component.component';


const routes : Routes =[

  {path :'' , component : MainComponentComponent  },
  { path : 'startQZ', component : QuestionComponent  }    
];

@NgModule({
  declarations: [
    AppComponent,
    QuestionComponent,
    NavigationComponent,
    MainComponentComponent,
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
   RouterModule.forRoot(routes),
   HttpModule,
   ModalModule.forRoot(),
    BootstrapModalModule
  ],
  providers: [ Question, Modal ],
  bootstrap: [AppComponent]

  
})



export class AppModule { }
